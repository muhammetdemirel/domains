const electron = require('electron');
const url = require('url');
const path = require('path');
const db = require('./lib/connection').db;
const {app, BrowserWindow, Menu, ipcMain, screen} = electron;
let mainWindow, mainMenu, mainMenuTemplate, domainList = [];

mainMenuTemplate = [
    {
        label: "Domain",
        submenu: [
            {
                label: "New Domain",
                click() {
                    createWindow({
                        width: 450,
                        height: 650,
                        title: "New Domain",
                        file: "newdomain"
                    })
                }
            },
            {
                label: "Delete Domain",
                click() {
                    createWindow({
                        width: 450,
                        height: 300,
                        title: "Delete Domain",
                        file: "deletedomain"
                    })
                }
            }
        ]
    },
    {
        label: "Quit",
        accelerator: process.platform === "darwin" ? "Command+Q" : "Ctrl+Q",
        role: "quit"
    }
]

if (process.platform === "darwin") {
    mainMenuTemplate.unshift({
        label: app.getName(),
        role: "Domains"
    })
}

app.on('ready', () => {

    const getSize = {width, height} = screen.getPrimaryDisplay().size;
    createWindow({
        width: getSize.width,
        height: getSize.height,
        file: "index",
        main: true
    })

    mainMenu = Menu.buildFromTemplate(mainMenuTemplate)
    Menu.setApplicationMenu(mainMenu)

    ipcMain.on("key:deleteDomain", (error, data) => {
        if (data) {
            db.query("DELETE FROM domains WHERE domain_id = ?", data[0], (error, results, fields) => {
                if (error) {
                    console.log(error)
                }

                if (results.affectedRows > 0) {
                    mainWindow.webContents.send('domains:deleteRow', data[0])
                }
            })
        }
    })

    ipcMain.on("key:newDomain", (error, data) => {
        if (data) {
            let domain = {
                domain_id: domainList.length,
                domain_name: data[0],
                domain_registrar: data[1],
                domain_register_date: data[2],
                domain_expires_date: data[3],
                domain_notes: data[4]
            }
            domainList.push(domain)

            db.query("INSERT INTO domains (domain_name, domain_registrar, domain_register_date, domain_expires_date, domain_notes) VALUES (?, ?, ?, ?, ?)", [domain.domain_name, domain.domain_registrar, domain.domain_register_date, domain.domain_expires_date, domain.domain_notes], (error, results, fields) => {
                if (error) {
                    console.log(error)
                }

                if (results.insertId > 0) {
                    domain.domain_id = results.insertId;
                    mainWindow.webContents.send("domains:addItem", domain)
                }
            })
        }
    })

    mainWindow.webContents.once('dom-ready', () => {
        db.query("SELECT * FROM domains", (error, results, fields) => {
            if (error) {
                console.log(error)
            }

            mainWindow.webContents.send('domains:initApp', results)
        })

        db.query("SELECT * FROM settings", (error, results, fields) => {
            if (error) {
                console.log(error)
            }

            mainWindow.webContents.send('settings:allValue', results)
        })
    })

})

function createWindow(create = null) {
    let addWindow;

    if (create == null) {
        create = {
            width: 800,
            height: 600,
            resizable: false,
            frame: true,
            title: app.getName(),
            file: "404",
            main: false
        }
    }
    if (!create.width) {
        create.width = 800;
    }
    if (!create.height) {
        create.height = 600;
    }
    if (!create.resizable) {
        create.resizable = false;
    }
    if (!create.frame) {
        create.frame = true;
    }
    if (!create.title) {
        create.title = app.getName();
    }
    if (!create.file) {
        create.file = "404";
    }
    if (!create.main) {
        create.main = false;
    }

    if (create.main === true) {
        mainWindow = new BrowserWindow({
            width: create.width,
            height: create.height,
            title: create.title,
            frame: create.frame,
            webPreferences: {
                nodeIntegration: true
            }
        })

        mainWindow.setResizable(create.resizable)

        mainWindow.loadURL(
            url.format({
                pathname: path.join(__dirname, "public/" + create.file + ".html"),
                protocol: "file:",
                slashes: true
            })
        )

        mainWindow.on('close', () => {
            app.quit()
        })
    } else {
        addWindow = new BrowserWindow({
            width: create.width,
            height: create.height,
            title: create.title,
            frame: create.frame,
            webPreferences: {
                nodeIntegration: true
            }
        })

        addWindow.setResizable(create.resizable)

        addWindow.loadURL(
            url.format({
                pathname: path.join(__dirname, "public/" + create.file + ".html"),
                protocol: "file:",
                slashes: true
            })
        )

        addWindow.on('close', () => {
            addWindow = null;
        })
    }
}
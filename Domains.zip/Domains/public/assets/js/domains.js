const $ = require('jquery');
const electron = require('electron');
const {ipcRenderer} = electron;
require('popper.js');
require('bootstrap');
require('datatables.net-dt')(window, $);

$(document).ready(function () {

    let table = $('#dataTableContent').DataTable();

    function alerts(className, message) {
        let code = `
            <div class="alert alert-${className} my-4" role="alert">${message}</div>
        `;

        return code;
    }

    $('#modalOne').on('show.bs.modal', function (event) {
        $('#alertModal').html('').addClass('d-none');

        let button = $(event.relatedTarget),
            recipient = button.data('whatever'),
            modal = $(this);

        modal.find('.modal-title').text(recipient);

        if (recipient === "New Domain") {
            $('#newDomain').removeClass("d-none");
            $('#deleteDomain').addClass("d-none");
        } else if (recipient === "Delete Domain") {
            $('#newDomain').addClass("d-none");
            $('#deleteDomain').removeClass("d-none");
        }
    });

    $('#formDeleteDomain').submit(function (e) {
        e.preventDefault();
        let deleteDomain = [
            $('input[name="formId"]').val()
        ];

        if (deleteDomain[0]) {
            $('#alertModal').html(alerts('success', "Domain deleted successfully.")).removeClass('d-none');
            setTimeout(() => {
                $('#alertModal').html('').addClass('d-none');
            }, 3000);

            ipcRenderer.send("key:deleteDomain", deleteDomain);

            $('#formDeleteDomain')[0].reset();
        } else {
            $('#alertModal').html(alerts('danger', "You need to fill in all fields.")).removeClass('d-none');
            setTimeout(() => {
                $('#alertModal').html('').addClass('d-none');
            }, 3000);
        }
    });

    $('#formNewDomain').submit(function (e) {
        e.preventDefault();
        let newDomain = [
            $('input[name="formDomain"]').val(),
            $('input[name="formRegistrar"]').val(),
            $('input[name="formRegisterDate"]').val(),
            $('input[name="formExpiresDate"]').val(),
            $('textarea[name="formNotes"]').val()
        ];

        if (newDomain[0] && newDomain[1] && newDomain[2] && newDomain[3] && newDomain[4]) {
            $('#alertModal').html(alerts('success', "Domain added successfully.")).removeClass('d-none');
            setTimeout(() => {
                $('#alertModal').html('').addClass('d-none');
            }, 3000);

            ipcRenderer.send("key:newDomain", newDomain);

            $('#formNewDomain')[0].reset();
        } else {
            $('#alertModal').html(alerts('danger', "You need to fill in all fields.")).removeClass('d-none');
            setTimeout(() => {
                $('#alertModal').html('').addClass('d-none');
            }, 3000);
        }
    });

    ipcRenderer.on('domains:addItem', (error, domain) => {
        if (domain) {
            $('#domainList').html('');

            let code = `
                <tr data-domain-id="${domain.domain_id}">
                    <td>${domain.domain_id}</td>
                    <td>${domain.domain_name}</td>
                    <td>${domain.domain_registrar}</td>
                    <td>${domain.domain_register_date}</td>
                    <td>${domain.domain_expires_date}</td>
                    <td>${domain.domain_notes}</td>
                </tr>
            `;

            table.row.add($(code)).draw(false);
        }
    })

    ipcRenderer.on('domains:initApp', (error, domains) => {
        if (domains) {
            domains.forEach(domain => {
                let code = `
                    <tr data-domain-id="${domain.domain_id}">
                        <td>${domain.domain_id}</td>
                        <td>${domain.domain_name}</td>
                        <td>${domain.domain_registrar}</td>
                        <td>${domain.domain_register_date}</td>
                        <td>${domain.domain_expires_date}</td>
                        <td>${domain.domain_notes}</td>
                    </tr>
                `;

                table.row.add($(code)).draw(false);
            })
        }
    })

    ipcRenderer.on('domains:deleteRow', (error, id) => {
        if (id) {
            table.rows('tr[data-domain-id="' + id + '"]').remove().draw();
        }
    })

    ipcRenderer.on('settings:allValue', (error, values) => {
        if (values) {
            values.forEach(value => {
                if (value.setting_name === "theme") {
                    $('body').attr('data-theme', value.setting_value)
                }
            })
        }
    })

});